from collections import deque
import numpy as np


class BaseOnlineNormalizer:
    def __init__(self, epsilon=1e-8):
        self.epsilon = float(epsilon)

    def transform(self, values):
        return self.clean(values)

    def update(self, values):
        return None

    def reset(self):
        return None

    def clean(self, values):
        cleanValues = np.asarray(values, dtype=np.float64)
        return np.nan_to_num(
            cleanValues,
            nan=0.0,
            posinf=np.finfo(np.float32).max,
            neginf=np.finfo(np.float32).min,
        )

class NoOnlineNormalizer(BaseOnlineNormalizer):
    pass

class IncrementalZScoreNormalizer(BaseOnlineNormalizer):
    def __init__(self, epsilon=1e-8, clip=None):
        super().__init__(epsilon)
        self.clip = clip
        self.reset()

    def transform(self, values):
        cleanValues = self.clean(values)
        if self.count < 2:
            return np.zeros_like(cleanValues)
        variance = self.squareDistance / max(self.count - 1, 1)
        deviation = np.sqrt(np.maximum(variance, 0.0))
        safeDeviation = np.where(deviation < self.epsilon, 1.0, deviation)
        normalized = (cleanValues - self.mean) / safeDeviation
        if self.clip is not None:
            normalized = np.clip(normalized, -float(self.clip), float(self.clip))
        return normalized

    def update(self, values):
        cleanValues = self.clean(values)
        if self.count == 0:
            self.count = 1
            self.mean = cleanValues.copy()
            self.squareDistance = np.zeros_like(cleanValues)
            return
        self.count += 1
        difference = cleanValues - self.mean
        self.mean = self.mean + (difference / self.count)
        secondDifference = cleanValues - self.mean
        self.squareDistance = self.squareDistance + (difference * secondDifference)

    def reset(self):
        self.count = 0
        self.mean = None
        self.squareDistance = None