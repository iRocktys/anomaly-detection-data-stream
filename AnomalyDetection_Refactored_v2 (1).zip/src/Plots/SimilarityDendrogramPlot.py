from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.spatial.distance import squareform


class SimilarityDendrogramPlot:
    def plot(self, distanceMatrix, outputPath):
        # Gera um dendrograma a partir da matriz simétrica de distâncias entre ataques.
        output_path = Path(outputPath)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        if len(distanceMatrix) < 2:
            raise ValueError("The dendrogram requires at least two attacks.")
        condensed = squareform(distanceMatrix.to_numpy(dtype=float), checks=False)
        linked = linkage(condensed, method="average")
        figure, axis = plt.subplots(figsize=(10, 6))
        dendrogram(linked, labels=list(distanceMatrix.index), ax=axis)
        axis.set_title("Attack Similarity Dendrogram")
        axis.set_xlabel("Attack")
        axis.set_ylabel("Mahalanobis Distance")
        figure.tight_layout()
        figure.savefig(output_path, dpi=160, bbox_inches="tight")
        plt.close(figure)
        return output_path
