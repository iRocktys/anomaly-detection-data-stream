import numpy as np
import pandas as pd
from capymoa.stream import NumpyStream


class DataStreamProcessor:
    def __init__(self, logging=True, selected_features=None, removed_features=None):
        # Inicializa o processador com seleção e remoção opcionais de features.
        self.logging = bool(logging)
        self.selected_features = selected_features
        self.removed_features = removed_features

    def _log(self, message):
        # Exibe mensagens de processamento somente quando o logging estiver habilitado.
        if self.logging:
            print(message)

    def _validate_dataframe(self, df, target_label_col):
        # Valida o DataFrame de entrada e a presença da coluna de rótulo.
        if not isinstance(df, pd.DataFrame):
            raise TypeError("The dataset must be a pandas DataFrame.")
        if target_label_col not in df.columns:
            raise ValueError(f"Target column '{target_label_col}' was not found in the dataset.")

    def _remove_invalid_label_rows(self, df, target_label_col):
        # Remove linhas sem rótulo válido antes de construir a stream binária.
        normalized_labels = df[target_label_col].astype("string").str.strip()
        invalid_mask = normalized_labels.isna() | normalized_labels.fillna("").eq("")
        cleaned_df = df.loc[~invalid_mask].copy().reset_index(drop=True)
        return cleaned_df, int(invalid_mask.sum())

    def _select_features(self, df, target_label_col):
        # Mantém somente as features selecionadas e a coluna de rótulo quando houver seleção explícita.
        if self.selected_features is None:
            return df.copy()
        selected_features = [str(feature).strip() for feature in self.selected_features]
        missing_features = [feature for feature in selected_features if feature not in df.columns]
        if missing_features:
            raise ValueError(f"Selected features were not found in the dataset: {missing_features}")
        columns_to_keep = list(selected_features)
        if target_label_col not in columns_to_keep:
            columns_to_keep.append(target_label_col)
        return df[columns_to_keep].copy()

    def _remove_features(self, df, target_label_col):
        # Remove somente features existentes sem permitir a exclusão da coluna de rótulo.
        if self.removed_features is None:
            return df
        removed_features = [str(feature).strip() for feature in self.removed_features]
        removed_features = [feature for feature in removed_features if feature != target_label_col]
        existing_features = [feature for feature in removed_features if feature in df.columns]
        return df.drop(columns=existing_features)

    def _prepare_features(self, df, target_label_col):
        # Converte as features para valores numéricos preservando ausências para a imputação online.
        features = df.drop(columns=[target_label_col]).apply(pd.to_numeric, errors="coerce")
        features = features.replace([np.inf, -np.inf], np.nan)
        if features.shape[1] == 0:
            raise ValueError("No feature remained after dataset preprocessing.")
        return features.astype(np.float64)

    def _prepare_original_labels(self, labels):
        # Normaliza os rótulos originais preservando o nome real do ataque apenas como metadado.
        original_labels = labels.astype("string").str.strip()
        invalid_mask = original_labels.isna() | original_labels.fillna("").eq("")
        if invalid_mask.any():
            invalid_indices = original_labels.index[invalid_mask].tolist()
            raise ValueError(f"Missing or empty labels were found at rows {invalid_indices[:10]}.")
        return original_labels.astype(str)

    def _encode_binary_labels(self, original_labels):
        # Converte BENIGN ou NORMAL para zero e qualquer ataque para um no alvo experimental.
        normal_labels = {"BENIGN", "NORMAL", "0"}
        encoded_labels = np.where(
            original_labels.str.upper().isin(normal_labels),
            0,
            1,
        ).astype(np.int32)
        return encoded_labels, ["BENIGN", "ATTACK"]

    def create_stream(self, df, target_label_col="Label", binary_label=True):
        # Constrói uma NumpyStream binária mantendo nomes de features e rótulos originais alinhados.
        if not bool(binary_label):
            raise ValueError("Only binary stream encoding is supported; binary_label must remain True.")
        processed_df = df.copy()
        processed_df.columns = processed_df.columns.astype(str).str.strip()
        target_label_col = str(target_label_col).strip()
        self._validate_dataframe(processed_df, target_label_col)
        processed_df, removed_label_rows = self._remove_invalid_label_rows(processed_df, target_label_col)
        self._log(f"Linhas removidas por rótulo ausente ou vazio: {removed_label_rows}.")
        if processed_df.empty:
            raise ValueError("All rows were removed because no valid label remained.")
        processed_df = self._select_features(processed_df, target_label_col)
        processed_df = self._remove_features(processed_df, target_label_col)
        original_labels = self._prepare_original_labels(processed_df[target_label_col])
        features = self._prepare_features(processed_df, target_label_col)
        encoded_labels, target_names = self._encode_binary_labels(original_labels)
        feature_names = features.columns.tolist()
        feature_values = features.to_numpy(dtype=np.float64)
        label_names = original_labels.tolist()
        if len(feature_values) != len(encoded_labels) or len(encoded_labels) != len(label_names):
            raise RuntimeError("Feature values and binary labels have different lengths.")
        stream = NumpyStream(
            feature_values,
            encoded_labels,
            target_name=target_label_col,
            feature_names=feature_names,
            target_type="categorical",
        )
        self._log(f"Stream criada com {feature_values.shape[0]} instâncias e {feature_values.shape[1]} features.")
        self._log("Treinamento configurado exclusivamente como binário: BENIGN=0 e ATTACK=1.")
        self._log(f"Valores ausentes preservados para imputação online: {int(np.isnan(feature_values).sum())}.")
        return stream, target_names, feature_names, label_names
